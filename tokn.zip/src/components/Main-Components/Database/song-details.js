const songDetails = [
    {
      id: 1,
      img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRlDsCSHvf59RaKQKnFeRynJmeri0sVyfTexw&usqp=CAU",
      title: "Mask Off",
      artist: "Future"
    },
    {
      id: 2,
      img: "http://blog.spoongraphics.co.uk/wp-content/uploads/2017/album-art/12.jpg",
      title: "Still Be Friends",
      artist: "G-Eazy ft. Tory Lanez, Tyga"
      },
    {
      id: 3,
      img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQMGMg7abDMGGnV5nWEAKQKoo5mwtVdmjP-hg&usqp=CAU",
      title: "Trap Queen",
      artist: "Fetty Wap"
    },
  
    {
      id: 5,
      img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSD-HPVy8w5-DliEcTYCXXdpEyWh9SToJqBOQ&usqp=CAU",
      title: "A Sky Full Of Stars ",
      artist: "Coldplay"
    },
    {
      id: 6,
      img: "https://www.udiscovermusic.com/wp-content/uploads/2015/10/Janelle-Mona%CC%81e-Dirty-Computer-.jpg",
      title: "24K Magic",
      artist: "Burno Mars"
    },
    {  
      id: 7,
      img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTi4DIH2wnuFma0PXV8LVJ5EFZPop9qslQ5Dw&usqp=CAU",
      title: "Glamorous",
      artist: "Fergie ft. Ludacris"
    },
    {
      id: 8,
      img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSZiBMoey26m-YI8WZR6TeXHEowSYyFx_OC5g&usqp=CAU",
      title: " Knife Talk",
      artist: "Drake  ft. 21 Savage, Project Pat"
      },
    {
      id: 9,
      img: "https://centaur-wp.s3.eu-central-1.amazonaws.com/designweek/prod/content/uploads/2020/08/14151506/PL-FutureUtopia-12Questions-FINAL.jpg",
      title: " Barbie Girl",
      artist: "Aqua"
    },
    {
      id: 10,
      img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTEqNiQO8nwGxEznzfzArvnBupQafCDXLbUCQ&usqp=CAU&width=1200&fit=bounds",
      title: "End Game",
      artist: "Taylor Swift ft. Ed Sheeran, Future"
    },
    {
      id: 11,
      img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSKSTz67cNNJowPHPlujabaNCFFRBI9RwntSQ&usqp=CAU",
      title: "Sugar",
      artist: "Flo rida"
    },
    {
      id: 12,
      img: "https://images.squarespace-cdn.com/content/v1/5befb3b84611a081dd003798/1542448368733-1HATLV3VPTG1143NA9KE/Noopur.jpg",
      title: "Replay",
      artist: "IYAZ"
    },
    {
      id: 12,
      img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTbllX9k2S_RwHhiphUdrOVkwIxtqUiUjl_iA&usqp=CAU",
      title: "Bikash",
      artist: "Rockstar"
    },
    
  ];
  
  export default songDetails;