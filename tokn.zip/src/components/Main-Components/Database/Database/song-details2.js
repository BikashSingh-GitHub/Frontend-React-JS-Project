const songfix = [
    {
      id: 1,
      img: "https://i.pinimg.com/originals/31/a5/f8/31a5f8a724e12d133e08bb6d72d9ed57.jpg",
      title: "Christmas Love",
      artist: "Justin Bieber"
    },
    {
      id: 2,
      img: "https://c.saavncdn.com/330/Red-Taylor-s-Version--English-2021-20211112114609-500x500.jpg",
      title: "Message In A Bottle (Taylor's Version) (From The Vault)",
      artist: "Taylor Swift"
      },
    {
      id: 3,
      img: "https://i1.sndcdn.com/artworks-000067079650-gq7eqm-t500x500.jpg",
      title: "The Lazy Song",
      artist: "Bruno Mars"
    },
    {
      id: 3,
      img: "https://upload.wikimedia.org/wikipedia/en/5/5b/WizPromises.jpg",
      title: "Promises",
      artist: "Wiz Khalifa"
    },
    {
      id: 4,
      img: "https://upload.wikimedia.org/wikipedia/en/f/f2/Taylor_Swift_-_Reputation.png",
      title: "Reputation",
      artist: "Taylor Swift"
    },
    {
      id: 5,
      img: "https://c.saavncdn.com/845/Life-Is-Good-English-2020-20200109182729-500x500.jpg",
      title: "Life is Good",
      artist: "Future"
    },
    {
      id: 6,
      img: "https://i1.sndcdn.com/artworks-000028293188-fcgfg7-t500x500.jpg",
      title: "21 Guns",
      artist: "Green Day"
    },
    {  
      id: 7,
      img: "https://upload.wikimedia.org/wikipedia/en/d/d6/She_Doesn%27t_Mind.jpg",
      title: "She Doesn't Mind",
      artist: "Sean Paul"
    },
    {
      id: 8,
      img: "https://upload.wikimedia.org/wikipedia/en/3/36/Low_fr_tp.JPG",
      title: "Low",
      artist: "Flo Rida"
      },

  ];
  
  export default songfix;