const songDetails = [
    {
      id: 1,
      img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTlUJlAcWL4AoZeK88qoL6e1nLLSratjqJaZA&usqp=CAU",
      title: "Mask Off",
      artist: "Future"
    },
    {
      id: 2,
      img: "https://mir-s3-cdn-cf.behance.net/project_modules/max_1200/4bb82b72535211.5bead62fe26d5.jpg",
      title: "Still Be Friends",
      artist: "G-Eazy ft. Tory Lanez, Tyga"
      },
    {
      id: 3,
      img: "https://i.pinimg.com/originals/31/a5/f8/31a5f8a724e12d133e08bb6d72d9ed57.jpg",
      title: "Trap Queen",
      artist: "Fetty Wap"
    },
  
    {
      id: 5,
      img: "https://upload.wikimedia.org/wikipedia/en/8/8d/Coldplay_-_A_Sky_Full_of_Stars_%28Single%29.png",
      title: "A Sky Full Of Stars ",
      artist: "Coldplay"
    },
    {
      id: 6,
      img: "https://www.udiscovermusic.com/wp-content/uploads/2015/10/Janelle-Mona%CC%81e-Dirty-Computer-.jpg",
      title: "24K Magic",
      artist: "Burno Mars"
    },
    {  
      id: 7,
      img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTi4DIH2wnuFma0PXV8LVJ5EFZPop9qslQ5Dw&usqp=CAU",
      title: "Glamorous",
      artist: "Fergie ft. Ludacris"
    },
    {
      id: 8,
      img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSZiBMoey26m-YI8WZR6TeXHEowSYyFx_OC5g&usqp=CAU",
      title: " Knife Talk",
      artist: "Drake  ft. 21 Savage, Project Pat"
      },
    {
      id: 9,
      img: "https://centaur-wp.s3.eu-central-1.amazonaws.com/designweek/prod/content/uploads/2020/08/14151506/PL-FutureUtopia-12Questions-FINAL.jpg",
      title: " Barbie Girl",
      artist: "Aqua"
    },
    {
      id: 10,
      img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTEqNiQO8nwGxEznzfzArvnBupQafCDXLbUCQ&usqp=CAU&width=1200&fit=bounds",
      title: "End Game",
      artist: "Taylor Swift ft. Ed Sheeran, Future"
    },
    {
      id: 11,
      img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSKSTz67cNNJowPHPlujabaNCFFRBI9RwntSQ&usqp=CAU",
      title: "Sugar",
      artist: "Flo rida"
    },
    {
      id: 12,
      img: "https://images.squarespace-cdn.com/content/v1/5befb3b84611a081dd003798/1542448368733-1HATLV3VPTG1143NA9KE/Noopur.jpg",
      title: "Replay",
      artist: "IYAZ"
    },
  
  ];
  
  export default songDetails;