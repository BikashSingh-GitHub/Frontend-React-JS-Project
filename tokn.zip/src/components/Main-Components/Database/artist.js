const artist=
[
    {
      id: 1,
      img: "https://media1.popsugar-assets.com/files/thumbor/zan-t_Me63if8oqWYE9ENiPLlhA/0x224:2826x3050/fit-in/2048xorig/filters:format_auto-!!-:strip_icc-!!-/2020/02/11/894/n/1922398/87f6bb525e430e7bd44e40.22278576_/i/Drake.jpg",
      artist: "Drake"
    },
    {
      id: 2,
      img: "https://c.saavncdn.com/artists/21_Savage_20190823071304_500x500.jpg",
      artist: "21 Savage"
      },
    {
      id: 3,
      img: "https://c.saavncdn.com/artists/Coldplay_500x500.jpg",
      artist: "Coldplay"
      },
    {
      id: 4,
      img: "https://c.saavncdn.com/artists/Bruno_Mars_500x500.jpg",
      artist: "Bruno Mars"
      },
    {
      id: 5,
      img: "https://c.saavncdn.com/artists/Future_500x500.jpg",
      artist: "Future"
    },
    {
      id: 6,
      img: "https://c.saavncdn.com/artists/G-Eazy_002_20190312085846_500x500.jpg",
      artist: "G-Eazy"
    },
    {
      id: 7,
      img: "https://c.saavncdn.com/artists/Katy_Perry_004_20200616105931_500x500.jpg",
      artist: "Katy Perry"
    },
    {
      id: 8,
      img: "https://c.saavncdn.com/artists/Justin_Bieber_005_20201127112218_500x500.jpg",
      artist: "Justin Bieber"
    },
    {
      id: 9,
      img: "https://c.saavncdn.com/artists/Eminem_500x500.jpg",
      artist: "Eminem"
    },
    {
      id: 10,
      img: "https://c.saavncdn.com/artists/Enrique_Iglesias_500x500.jpg",
      artist: "Enrique Iglesias"
      },
    {
      id: 11,
      img: "https://c.saavncdn.com/artists/Flo_Rida_500x500.jpg",
      artist: "Flo Rida"
      },
    {
      id: 12,
      img: "https://c.saavncdn.com/artists/Chris_Brown_500x500.jpg",
      artist: "Chrish Brown"
    },

  {
    id: 13,
    img: "https://c.saavncdn.com/artists/Jay_Sean_500x500.jpg",
    artist: "Jay Sean"
  },
  {
    id: 14,
    img: "https://c.saavncdn.com/artists/David_Guetta_002_20200921152629_500x500.jpg",
    artist: "David Guetta"
  },
  {
    id: 15,
    img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRqxW4Ycnywq_iHiKZM-lZkGXQ-D8579fKMpw&usqp=CAU",
    artist: "T-Pain"
  },
  {
    id: 16,
    img: "https://c.saavncdn.com/artists/Sean_Paul_002_20190911070339_500x500.jpg",
    artist: "Sean Paul"
  },
  {
    id: 17,
    img: "https://c.saavncdn.com/artists/Nelly_500x500.jpg",
    artist: "Nelly"
  },
  {
    id: 18,
    img: "https://yt3.ggpht.com/XsjK_k4msgeQWO4xZDdEU3ExccLVkmPNnwNwDL4ivJJhnXXG-9FoLMecy_ro4JOjyh6O2Z5ITac=s900-c-k-c0x00ffffff-no-rj",
    artist: "Tyga"
  },
    ];
    
    
export default artist;

