import React from "react";
import { Link, withRouter } from "react-router-dom";
import placebid from '../images/placebid.jpg';
import emoji from '../images/emoji.png';
import spotify from '../images/spotify.png';
import apple from '../images/apple.png';
import "./Main.css";
import { CgProfile} from 'react-icons/cg';
import { AiOutlineTool} from 'react-icons/ai';

function Settings() {
  return (
    <div className="Settingshead">
     <div className="settingsicon1"><CgProfile/> <div className="ko">Profile</div></div>
     <div className="settingsicon2"><AiOutlineTool/> <div className="ko">Advance Settings</div></div>
    <div className="settingsleftcontainer "></div>
    <div className="settingsrightcontainer ">  <button className="setconf">Confirm</button>
    </div>  <div className="circleset"></div>

        </div>
  
  );
}

export default Settings;
