import React from "react";
import { Link, withRouter } from "react-router-dom";
import coverart from '../images/coverart.jpg';
import emoji from '../images/emoji.png';
import spotify from '../images/spotify.png';
import apple from '../images/apple.png';
import "./Main.css";
import { AiFillInfoCircle} from 'react-icons/ai';


function SongProfile() {
  return (
    
    <div className="headpage1">
   <div className="Profile">
    <div className="newsongprofile"></div>
         

    
       <div className="profilelive"> LIVE</div>  
       <div className="artistbox">   <div className="songprofilecircle"></div>  </div> 
       <img src={emoji} className="emoji"   />
       <div className="artistboxname">Artists Name</div>
 
<div className="profilebackground"></div>
       <h1 className="songtitleprofile"> Song Title</h1>
        
<img src={spotify} className="spotify"/> 
    < img src={apple} className="apple"/> 
    <div className="spt1"><div className="iconfix"><AiFillInfoCircle/></div>Price per Token:</div>
    <div className="spt2"></div>
    <div className="spt1"><div className="iconfix"><AiFillInfoCircle/></div>Total Quantity:</div>
    <div className="spt2"></div>
    <div className="spt1"><div className="iconfix"><AiFillInfoCircle/></div>Total Royalty %:</div>
    <div className="spt2"></div>
    <div className="spt1"><div className="iconfix"><AiFillInfoCircle/></div>Royalty % per Token:</div>
    <div className="spt2"></div>
    <Link to="Placebid">
    <button className="placebidprofile">Place Bid</button></Link>
    <Link to="BuyNow">
    <button className="buynowprofile">Buy Now</button></Link>
   
         

       
 
   

        <span className="songcoverimage"> <img src={coverart} className="picio"   /> </span>
       
       
        </div>
        {/* <div className="termtext">By clicking above, you acknowledge and adhere to our Terms or Service , Purchasers agreement , and all other Legal.</div>
       <div className="termtext2">ROYALTIES WILL BEGIN SENDING AFTER BETA</div> */}
        </div>
  
  );
}

export default SongProfile;
